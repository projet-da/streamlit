- Aller sur le site streamlit : https://streamlit.io/cloud
- Cliquer sur "Get Started"
  ![image](https://github.com/projet-da/streamlit/assets/67692878/43b1fe8d-4bb6-4708-bfad-b8f304d61194)

- Cliquer sur "New app" -> "Use existing repo"
  ![image](https://github.com/projet-da/streamlit/assets/67692878/406c55b8-75a0-43fe-8569-e13a00ead7ed)

- "Connect to GitHub"
  ![image](https://github.com/projet-da/streamlit/assets/67692878/10ca72cf-ecdc-4bd1-be6a-be93ca9a2d0c)

- Modifier les infos du repo puis "Deploy" MAIS NE FONCTIONNE PAS SOUVENT ;(
![image](https://github.com/projet-da/streamlit/assets/67692878/1be329cd-9a90-47b7-892e-e7e4a7e0906c)

- L'application démarre
![image](https://github.com/projet-da/streamlit/assets/67692878/3bf72b9e-4c96-4d9c-8509-68b39e2ebca1)
